package domain.model;
public enum EstadoEquipo { OPERATIVO, EN_REPARACION, BAJA }
