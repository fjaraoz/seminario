package domain.model;
public enum TipoEquipo { PC, IMPRESORA, ESCANER, MONITOR }
