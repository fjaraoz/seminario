package domain.model;
public enum Role { LECTURA, EDICION, ADMIN }
