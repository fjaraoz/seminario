package domain.model;

public enum EstadoReparacion { ABIERTA, EN_PROCESO, CERRADA }
